alias ExBin.{Snippet, Repo}
alias ExBin.Domain, as: L
