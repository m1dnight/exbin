defmodule ExBinWeb.LayoutViewTest do
  use ExBinWeb.ConnCase, async: true
end
