defmodule ExBinWeb.PageViewTest do
  use ExBinWeb.ConnCase, async: true
end
