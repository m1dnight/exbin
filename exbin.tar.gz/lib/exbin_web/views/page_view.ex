defmodule ExBinWeb.PageView do
  use ExBinWeb, :view
end
