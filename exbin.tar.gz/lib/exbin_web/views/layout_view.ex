defmodule ExBinWeb.LayoutView do
  use ExBinWeb, :view
end
